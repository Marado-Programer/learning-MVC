# Change Log

All notable changes to this publication will be documented in this file.

## 1.0.00 - 2022-26-05

First release. Add notification system and partner permissions manager.

## 0.3.22 - 2022-25-05
Remaking some things.

## 0.3.21 - 2022-24-05
Remaking some things.

## 0.3.20 - 2022-23-05
Remaking some things.

## 0.3.19 - 2022-22-05
Partners can pay dues to renew their partnership.

## 0.3.18 - 2022-20-05
Association images.

## 0.3.17 - 2022-18-05
Can enter event.

Errors found:
- Partners(president) of Association Object are Users;
- Recursion on registrations because registrations has an event as events has registrations;
- Buying tickets/enter events duplicates the event on the view;
- Buying tickets button appears after other assoc enters it and you are a part of it;

## 0.3.16 - 2022-18-05
Can enter association.

## 0.3.15 - 2022-17-05
Trying to create a new DB system.

## 0.3.14 - 2022-17-05
Association can become part of events.

## 0.3.13 - 2022-16-05
Start Events system.

## 0.3.12 - 2022-16-05
``Finished'' news controller.

## 0.3.11 - 2022-15-05
Can create a news. Start news controller.

## 0.3.10 - 2022-14-05
Start news creator.

## 0.3.9 - 2022-14-04
New permissions.

## 0.3.8 - 2022-13-04
Start of the association admnistration panel.

## 0.3.7 - 2022-12-04
More Iterators. Need to do a test on this last one, and a factory method for the iterators.

## 0.3.6 - 2022-12-04
Search Associations using Iterator.
I want to add:
- a Proxy design pattern with the DB for cache (and controll of SQL queries for security too I think it's a good idea).
- an filter for the associations.

Start using the Singleton I made for the permissions checking(idk why I wasn't using before).

## 0.3.5 - 2022-11-04
Search associations. Has a lot of erros, tomorrow I see them.

## 0.3.4 - 2022-11-04
Can create associations.

## 0.3.3 - 2022-11-04
Create associations form.

## 0.3.2 - 2022-11-04
Starting associations controller.

## 0.3.1 - 2022-11-04
Little user login changes.

## 0.3.0 - 2022-10-04
I want to start implementing the classes, user registration.

## 0.2.2 - 2022-10-04
Start of the dues system.

## 0.2.1 - 2022-09-04
User registracion to events of an association.

## 0.2.0 - 2022-09-04
Started following the pdf my teacher gave me. The pdf it's on /docs (in portuguese).

## 0.1.0 - 2022-07-04
MainController it's an abstract class now.
Created a kind of a Factory Method for the controllers.

## 0.0.0 - 2022-07-04

Very incomplete.
