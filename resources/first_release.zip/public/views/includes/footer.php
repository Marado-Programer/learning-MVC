<?php

if (!defined('ROOT_PATH'))
    exit;

?>

<footer>
    <address>
    <p>João Torres --- n.º&nbsp;10 --- Programador/a de Informática - 2020 --- al220007</p>
    <hr />
    <p><a href="mailto:al220007@epcc.pt">al220007@epcc.pt</a></p>
    <p><a href="http://alunos.epcc.pt/~al220007/PHP">al220007 PHP</a></p>
    </address>
</footer>

</body>

</html>

