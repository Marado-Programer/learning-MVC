INSERT INTO `users` VALUES
(1,'marado','Augusto Marado','$2a$08$/q9T92IhZ6ETdhHUTwuQsOii.fmyrl80GrXFJnfjddl3h17Kbr29m','marado@marado.xyz','+351 918274344','dk3uuls9j9hbd5ov172cksn8h7','23',8.000);

