<?php

/**
 * First page loaded
 */

require_once './src/loader.php';

