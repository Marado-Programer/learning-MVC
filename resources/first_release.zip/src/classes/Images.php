<?php

/**
 *
 */

class Images
{
    private $title;

    public function __construct(string $title) {
        $this->title = $title;
    }

    public function insertImage(): void
    {

    }

    public function listImage(): void
    {

    }

    public function removeImage(): void
    {

    }
}

