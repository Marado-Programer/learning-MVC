Criei o meu próprio diagrama de classes baseado no seu.

![Class Diagram](./docs/classDiagram.svg)

Em ./resources existe o ficheiro .sql para a criacao da BD.

Em ./config esta o ficheiro de config.



