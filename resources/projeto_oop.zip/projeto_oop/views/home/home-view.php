<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap">
<p>Olá, <br /> funciona.</p>
</div> <!-- .wrap -->	
