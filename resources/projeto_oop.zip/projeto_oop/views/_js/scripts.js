$(function(){
    $('input[type=submit]').click(function(){
        alert("Form irá ser submetido.");
        });
    });