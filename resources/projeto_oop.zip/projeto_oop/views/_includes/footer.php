<?php if ( ! defined('ABSPATH')) exit; ?>

</div> <!-- .main-page (header.php) -->
footer
</body>
</html>
